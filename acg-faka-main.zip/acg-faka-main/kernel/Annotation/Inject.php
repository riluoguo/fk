<?php
declare(strict_types=1);

namespace Kernel\Annotation;

use JetBrains\PhpStorm\NoReturn;

#[\Attribute(\Attribute::TARGET_PROPERTY)]
class Inject
{
}